	jQuery(document).ready(function(jQuery)
		{	
			jQuery('.wcps_color').wpColorPicker();
		});