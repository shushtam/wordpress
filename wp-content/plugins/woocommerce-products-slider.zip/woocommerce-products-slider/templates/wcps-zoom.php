<?php

/*
* @Author 		PickPlugins
* Copyright: 	2015 PickPlugins
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 
	

	
	$html.= '<div class="wcps-zoom-thumb wcps-zoom-thumb-'.$post_id.'" >
				<span class="wcps-zoom-colse">X</span>
				<img src="" />
			</div>';